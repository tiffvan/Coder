﻿using System;
namespace Coder.Resources
{
    public class UserClass
    {
        public UserClass()
        {
        }
    }
}
