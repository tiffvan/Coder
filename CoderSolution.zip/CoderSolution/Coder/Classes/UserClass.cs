﻿using System;
using Coder.Classes;

namespace Coder
{
    public class UserClass
    {
        public string Name { get; set; }
        public string Email { get; set; }
        public string Uid { get; set; }
    }
}
