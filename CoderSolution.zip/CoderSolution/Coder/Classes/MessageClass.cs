﻿using System;
namespace Coder.Classes
{
    public class MessageClass
    {
        public string ItemName { get; set; }
        public DateTime ItemTime { get; set; }
    }
}
